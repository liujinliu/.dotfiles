"""In memory representation of snippet definitions."""

from UltiSnips.snippet.definition.ultisnips import UltiSnipsSnippetDefinition
from UltiSnips.snippet.definition.snipmate import SnipMateSnippetDefinition
